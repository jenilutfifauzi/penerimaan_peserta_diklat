<x-filament-panels::page>
    <style>
        .filament-login-logo img {
            height: 100rem; /* Atur ukuran sesuai kebutuhan */
        }
    </style>
</x-filament-panels::page>
